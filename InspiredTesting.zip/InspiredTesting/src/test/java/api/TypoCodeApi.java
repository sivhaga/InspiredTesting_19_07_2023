package api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.json.simple.JSONObject;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class TypoCodeApi extends DataTest  {
    String baseUrl	= "https://jsonplaceholder.typicode.com";

    @BeforeTest
    public void byPassCertificate()
    {
        RestAssured.useRelaxedHTTPSValidation();
    }

    @Test(priority	= 1, dataProvider="createData")
    public void createUser(int postId,String name, String email, String body)
    {
        JSONObject request = new JSONObject();

        System.out.print("Creating data : " + postId + "," + name);

        request.put("PostId",postId);
        request.put("Name",name);
        request.put("Email",email);
        request.put("Body",body);


        given().
                header("Content-Type","application/json").
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                body(request.toJSONString()).
        when().
                post(baseUrl+"/posts"). // baseUrl+"/post"
        then().
                log().all().// This will print out the body back into console
                statusCode(201); // validating the status code to be 201 for creating or 200 for success

    }

    public void print()
    {
        System.out.println("-----------------------------------------------BODY ENDED-------------------------------------------------------------------------------------");
    }


}

