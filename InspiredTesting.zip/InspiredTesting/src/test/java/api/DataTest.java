package api;

import org.testng.annotations.DataProvider;

public class DataTest {

    private String currentDate = java.time.LocalDate.now().toString();

    @DataProvider(name	= "createData")
    public Object[][] dataForCreate()
    {
        return new Object[][]{
                {1,"peter","sivhaga@hotmail.com",currentDate},
                {2,"james","sivhaga@yahoo.com", currentDate}
        };
    }

    @DataProvider(name	= "updateData")
    public Object[][] dataForUpdate()
    {
        return new Object[][]{
                {1,"peter_updated","sivhaga_updated@hotmail.com",currentDate},
                {2,"james_updated","sivhaga_updated@yahoo.com",currentDate}
        };
    }

    @DataProvider(name	= "deleteData")
    public Object[][] dataForDelete()
    {
        return new Object[][]{
                {1}
        };
    }
}