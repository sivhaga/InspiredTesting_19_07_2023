package ui;


import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utils.Utils;

public class JavaScriptAlerts extends Utils {

    @BeforeTest
    public void setup(){
        setupWebDriver();
    }
    @AfterTest
    public void tearDown() {
        driver.quit();
    }

    @Test(priority = 1)
    public void acceptAlert()  {

        driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[1]/button")).click();
        driver.switchTo().alert().accept();
        String expected = "You successfully clicked an alert";
        String actual= driver.findElement(By.id("result")).getText();
        Assert.assertEquals(expected,actual);

    }

    @Test(priority = 2)
    public void dismissAlert() {
        driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[2]/button")).click();
        driver.switchTo().alert().dismiss();
    }
    @Test(priority = 3)
    public void enterTextInPrompt(){
        driver.findElement(By.xpath("//*[@id=\"content\"]/div/ul/li[3]/button")).click();
        driver.switchTo().alert().sendKeys("Entering Text in Prompt");
        driver.switchTo().alert().accept();
    }


}
