package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utils {
    public static WebDriver driver;

    public WebDriver setupWebDriver(){

        String path = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver",path+"/drivers/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://the-internet.herokuapp.com/javascript_alerts");
        return driver;
    }
}
